
document.getElementById("contactform").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission (refreshing page)

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;

   
    const emailPattern = /^[^\s]+[^\s]+\.[^\s]+/;

    if (name === "" || email === "" || message === "") {
        alert("Please fill in all fields."); // Alert if any field is empty
    } else if (!emailPattern.test(email)) {
        alert("Please enter a valid email address."); // Alert if email is not valid
    } else {
        
        document.getElementById("successmessage").classList.remove("hidden");

       
        console.log("Name:", name);
        console.log("Email:", email);
        console.log("Message:", message);

        
        document.getElementById("contactform").reset();
    }
});

