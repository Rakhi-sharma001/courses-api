const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

let courses = require('./courses.json');

// Get all courses
app.get('/api/courses', (req, res) => {
  res.json(courses);
});

// Add a new course
app.post('/api/courses', (req, res) => {
  const newCourse = req.body;
  newCourse.id = courses.length + 1;
  courses.push(newCourse);
  fs.writeFileSync('./courses.json', JSON.stringify(courses));
  res.status(201).json(newCourse);
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
